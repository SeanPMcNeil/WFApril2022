var likesOne = document.querySelector("#likeOne").innerText;
console.log(likesOne);

function addLikeOne() {
    likesOne++;
    document.querySelector("#likeOne").innerText = likesOne;
    console.log(likesOne);
}

var likesTwo = document.querySelector("#likeTwo").innerText;
console.log(likesTwo);

function addLikeTwo() {
    likesTwo++;
    document.querySelector("#likeTwo").innerText = likesTwo;
    console.log(likesTwo);
}

var likesThree = document.querySelector("#likeThree").innerText;
console.log(likesThree);

function addLikeThree() {
    likesThree++;
    document.querySelector("#likeThree").innerText = likesThree;
    console.log(likesThree);
}